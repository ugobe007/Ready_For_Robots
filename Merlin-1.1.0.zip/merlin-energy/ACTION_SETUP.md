# Merlin Energy plugin 1.1.0

Upload `Merlin-1.1.0.zip`. The ChatGPT editor does not keep a session with the publisher, and this chat cannot submit the plugin for public review. Import the actions from `openapi.json` in this folder, or from `https://merlinenergy.net/openapi.json` after this API is deployed.

## Actions

`calculateBESSPayback` is the primary action. It estimates payback, IRA ITC, demand-charge savings, and NPV.

`calculateITCTaxCredits` and `analyzeTariffRates` are specialized fallbacks. Use them only for a tax-credit-only or peak-shaving-only request.

Every response is a preliminary estimate. It is not an engineering design, a tax opinion, a financing commitment, or utility approval.

Facility templates: car wash, cold storage, hotel, manufacturing.

The published prompt asks, in order: facility type, optional project name, monthly energy and peak demand, energy and demand-charge rates, battery size and power, solar, market defaults or project costs, domestic-content and energy-community bonuses, analysis period and discount rate, and whether to include a Merlin quote link.

## Package

- Package: `merlin-energy`
- Version: `1.1.0`
- Display name: Merlin Energy
- Skill: `truequote`
- Actions: `https://merlinenergy.net/openapi.json`
- MCP: `https://merlin-mcp-agent-production.up.railway.app/mcp`
